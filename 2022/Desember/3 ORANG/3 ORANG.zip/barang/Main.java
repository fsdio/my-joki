package barang;

/**
 * Main
 */
public class Main {

    public static void main(String[] args) {
        Barang.Main();
    }
}