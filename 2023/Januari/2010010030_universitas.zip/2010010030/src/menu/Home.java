/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package menu;

import com.formdev.flatlaf.FlatDarkLaf;
import db.config;
import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author fsdio
 */
public class Home extends javax.swing.JFrame {

    /**
     * Creates new form Home
     */
    public Home() {
        initComponents();
        getTanggal();
        setLayoutTable();
        getTableDosen();
        getTableMahasiswa();
        getTableMataKuliah();
        getListDosen();
    }
    
    public void getListDosen(){
        
        namadosenmatakuliah.removeAllItems();
        namadosenmatakuliah.addItem("Pilih Dosen");
        try {
            String sql = "SELECT nama_dosen FROM tb_dosen";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {                
                namadosenmatakuliah.addItem(rs.getString(1));
            }
        } catch (Exception e) {
        }
    }
    
    public void getTanggal(){
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("YYYY-MM-dd");
        tanggallahirdosen.setText(String.valueOf(format.format(date)));
        tanggallahirmahasiswa.setText(String.valueOf(format.format(date)));
    }
    
    public void setLayoutTable(){
        
        // GET DOSEN
        int colums_dosen = tbl_dosen.getColumnCount();
        lbl_dosen.setText(String.valueOf(tbl_dosen.getRowCount()));
        
        for (int i = 0; i < colums_dosen; i++) {
            DefaultTableCellRenderer centerDosen = new DefaultTableCellRenderer();
            centerDosen.setHorizontalAlignment(JLabel.CENTER);
            tbl_dosen.getColumnModel().getColumn(i).setCellRenderer(centerDosen);

            TableColumnModel columnDosen = tbl_dosen.getColumnModel();
            columnDosen.getColumn(i).setPreferredWidth(200);
            columnDosen.getColumn(i).setMaxWidth(200);
        }
        
        // GET MAHASISWA
        int colums_mahasiswa = tbl_mahasiswa.getColumnCount();
        lbl_mahasiswa.setText(String.valueOf(tbl_mahasiswa.getRowCount()));
        
        for (int i = 0; i < colums_mahasiswa; i++) {
            DefaultTableCellRenderer centerDosen = new DefaultTableCellRenderer();
            centerDosen.setHorizontalAlignment(JLabel.CENTER);
            tbl_mahasiswa.getColumnModel().getColumn(i).setCellRenderer(centerDosen);

            TableColumnModel columnDosen = tbl_mahasiswa.getColumnModel();
            columnDosen.getColumn(i).setPreferredWidth(200);
            columnDosen.getColumn(i).setMaxWidth(200);
        }
        
        // GET MATAKULIAH
        int colums_matakuliah = tbl_matakuliah.getColumnCount();
        lbl_matakuliah.setText(String.valueOf(tbl_matakuliah.getRowCount()));
        
        for (int i = 0; i < colums_matakuliah; i++) {
            DefaultTableCellRenderer centerDosen = new DefaultTableCellRenderer();
            centerDosen.setHorizontalAlignment(JLabel.CENTER);
            tbl_matakuliah.getColumnModel().getColumn(i).setCellRenderer(centerDosen);

            TableColumnModel columnDosen = tbl_matakuliah.getColumnModel();
            columnDosen.getColumn(i).setPreferredWidth(200);
            columnDosen.getColumn(i).setMaxWidth(200);
        }
        
        
    }
    
    public void getTableMataKuliah(){
        
        DefaultTableModel model = new DefaultTableModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        model.addColumn("KODE MATA KULIAH");
        model.addColumn("NAMA MATA KULIAH");
        model.addColumn("NAMA DOSEN");
        model.addColumn("SKS");
        
        try {
            
            String sql = "SELECT * FROM tb_matakuliah";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {                
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, "GAGAL MEMUAT DATA TABEL MATA KULIAH");
        }
        tbl_matakuliah.setModel(model);
        setLayoutTable();
    }
    
    public void getTableMahasiswa(){
        
        DefaultTableModel model = new DefaultTableModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        model.addColumn("NPM");
        model.addColumn("NAMA MAHASISWA");
        model.addColumn("TEMPAT LAHIR");
        model.addColumn("TANGGAL LAHIR");
        model.addColumn("NO TELEPON");
        model.addColumn("ALAMAT");
        
        try {
            
            String sql = "SELECT * FROM tb_mahasiswa";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {                
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, "GAGAL MEMUAT DATA TABEL MAHASISWA");
        }
        tbl_mahasiswa.setModel(model);
        setLayoutTable();
    }
    
    public void getTableDosen(){
        
        DefaultTableModel model = new DefaultTableModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        model.addColumn("NIDN");
        model.addColumn("NAMA DOSEN");
        model.addColumn("TEMPAT LAHIR");
        model.addColumn("TANGGAL LAHIR");
        model.addColumn("NO TELEPON");
        model.addColumn("ALAMAT");
        
        try {
            
            String sql = "SELECT * FROM tb_dosen";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {                
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, "GAGAL MEMUAT DATA TABEL DOSEN");
        }
        tbl_dosen.setModel(model);
        setLayoutTable();
    }
    
    public boolean getValidateDataDosen(){
        if(nidndosen.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NIDN !");
            nidndosen.requestFocus();
            return false;
        }else if(namadosen.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NAMA DOSEN !");
            namadosen.requestFocus();
            return false;
        }else if(tempatlahirdosen.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI TEMPAT LAHIR !");
            tempatlahirdosen.requestFocus();
            return false;
        }else if(tanggallahirdosen.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI TANGGAL LAHIR !");
            tanggallahirdosen.requestFocus();
            return false;
        }else if(telephonedosen.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NOMOR TELEPON !");
            telephonedosen.requestFocus();
            return false;
        }else if(alamatdosen.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI ALAMAT ANDA !");
            alamatdosen.requestFocus();
            return false;
        }
        return true;
    };
    
    public boolean getValidateDataMahasiswa(){
        if(npmmahasiswa.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NIDN !");
            npmmahasiswa.requestFocus();
            return false;
        }else if(namamahasiswa.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NAMA MAHASISWA !");
            namamahasiswa.requestFocus();
            return false;
        }else if(tempatlahirmahasiswa.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI TEMPAT LAHIR !");
            tempatlahirmahasiswa.requestFocus();
            return false;
        }else if(tanggallahirmahasiswa.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI TANGGAL LAHIR !");
            tanggallahirmahasiswa.requestFocus();
            return false;
        }else if(telephonemahasiswa.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NOMOR TELEPON !");
            telephonemahasiswa.requestFocus();
            return false;
        }else if(alamatmahasiswa.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI ALAMAT ANDA !");
            alamatmahasiswa.requestFocus();
            return false;
        }
        return true;
    };
    
    public boolean getValidateDataMataKuliah(){
        if(kodematakuliah.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI KODE MATA KULIAH !");
            kodematakuliah.requestFocus();
            return false;
        }else if(namamatakuliah.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI NAMA MATA KULIAH !");
            namamatakuliah.requestFocus();
            return false;
        }else if(namadosenmatakuliah.getSelectedIndex()==0){
            JOptionPane.showMessageDialog(rootPane, "ISI NAMA DOSEN !");
            namadosenmatakuliah.requestFocus();
            return false;
        }else if(sksmatakuliah.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "ISI SKS MATA KULIAH !");
            sksmatakuliah.requestFocus();
            return false;
        }
        return true;
    };
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        TAB_DOSEN = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        nidndosen = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btn_simpandosen = new javax.swing.JButton();
        btn_ubahdosen = new javax.swing.JButton();
        btn_hapusdosen = new javax.swing.JButton();
        btn_cleardosen = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_dosen = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        lbl_dosen = new javax.swing.JLabel();
        namadosen = new javax.swing.JTextField();
        tempatlahirdosen = new javax.swing.JTextField();
        tanggallahirdosen = new javax.swing.JTextField();
        telephonedosen = new javax.swing.JTextField();
        alamatdosen = new javax.swing.JTextField();
        TAB_MAHASISWA = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        npmmahasiswa = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        btn_simpanmahasiswa = new javax.swing.JButton();
        btn_ubahmahasiswa = new javax.swing.JButton();
        btn_hapusmahasiswa = new javax.swing.JButton();
        btn_clearmahasiswa = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_mahasiswa = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        lbl_mahasiswa = new javax.swing.JLabel();
        namamahasiswa = new javax.swing.JTextField();
        tempatlahirmahasiswa = new javax.swing.JTextField();
        tanggallahirmahasiswa = new javax.swing.JTextField();
        telephonemahasiswa = new javax.swing.JTextField();
        alamatmahasiswa = new javax.swing.JTextField();
        TAB_MATAKULIAH = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        kodematakuliah = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btn_simpanmatakuliah = new javax.swing.JButton();
        btn_ubahmatakuliah = new javax.swing.JButton();
        btn_hapusmatakuliah = new javax.swing.JButton();
        btn_clearmatakuliah = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_matakuliah = new javax.swing.JTable();
        jLabel25 = new javax.swing.JLabel();
        lbl_matakuliah = new javax.swing.JLabel();
        namamatakuliah = new javax.swing.JTextField();
        sksmatakuliah = new javax.swing.JTextField();
        namadosenmatakuliah = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jTabbedPane1.setTabLayoutPolicy(javax.swing.JTabbedPane.SCROLL_TAB_LAYOUT);

        TAB_DOSEN.setBackground(new java.awt.Color(0, 153, 153));
        TAB_DOSEN.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("NIDN");

        nidndosen.setText("ID-DOSEN-000");
        nidndosen.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nidndosenKeyReleased(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("NAMA DOSEN");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("TEMPAT LAHIR");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("TANGGAL LAHIR");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("TELEPHONE");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("ALAMAT");

        btn_simpandosen.setBackground(new java.awt.Color(153, 153, 153));
        btn_simpandosen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_simpandosen.setText("SIMPAN");
        btn_simpandosen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpandosenActionPerformed(evt);
            }
        });

        btn_ubahdosen.setBackground(new java.awt.Color(153, 153, 153));
        btn_ubahdosen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_ubahdosen.setText("UBAH");
        btn_ubahdosen.setEnabled(false);
        btn_ubahdosen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ubahdosenActionPerformed(evt);
            }
        });

        btn_hapusdosen.setBackground(new java.awt.Color(153, 153, 153));
        btn_hapusdosen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_hapusdosen.setText("HAPUS");
        btn_hapusdosen.setEnabled(false);
        btn_hapusdosen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusdosenActionPerformed(evt);
            }
        });

        btn_cleardosen.setBackground(new java.awt.Color(153, 153, 153));
        btn_cleardosen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_cleardosen.setText("CLEAR");
        btn_cleardosen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cleardosenActionPerformed(evt);
            }
        });

        tbl_dosen.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbl_dosen.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tbl_dosen.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_dosenMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_dosen);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setText("JUMLAH DATA");

        lbl_dosen.setBackground(new java.awt.Color(255, 255, 0));
        lbl_dosen.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_dosen.setForeground(new java.awt.Color(204, 204, 0));
        lbl_dosen.setText("0");

        tanggallahirdosen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tanggallahirdosenActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TAB_DOSENLayout = new javax.swing.GroupLayout(TAB_DOSEN);
        TAB_DOSEN.setLayout(TAB_DOSENLayout);
        TAB_DOSENLayout.setHorizontalGroup(
            TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_DOSENLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, TAB_DOSENLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_dosen))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 532, Short.MAX_VALUE)
                    .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(TAB_DOSENLayout.createSequentialGroup()
                            .addComponent(btn_simpandosen)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_ubahdosen, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_hapusdosen, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_cleardosen, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(TAB_DOSENLayout.createSequentialGroup()
                            .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel4)
                                .addComponent(jLabel3)
                                .addComponent(jLabel2)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6)
                                .addComponent(jLabel7))
                            .addGap(47, 47, 47)
                            .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(alamatdosen)
                                .addComponent(telephonedosen)
                                .addComponent(tanggallahirdosen, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                                .addComponent(namadosen)
                                .addComponent(tempatlahirdosen)
                                .addComponent(nidndosen)))))
                .addGap(22, 47, Short.MAX_VALUE))
        );
        TAB_DOSENLayout.setVerticalGroup(
            TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_DOSENLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TAB_DOSENLayout.createSequentialGroup()
                        .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(nidndosen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(namadosen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(tempatlahirdosen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5))
                    .addComponent(tanggallahirdosen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(telephonedosen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(alamatdosen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_simpandosen)
                    .addComponent(btn_ubahdosen)
                    .addComponent(btn_hapusdosen)
                    .addComponent(btn_cleardosen))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(TAB_DOSENLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_dosen)
                    .addComponent(jLabel8))
                .addGap(8, 8, 8))
        );

        jTabbedPane1.addTab("DOSEN", TAB_DOSEN);

        TAB_MAHASISWA.setBackground(new java.awt.Color(0, 153, 153));
        TAB_MAHASISWA.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("NPM");

        npmmahasiswa.setText("ID-MHS-000");
        npmmahasiswa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                npmmahasiswaKeyReleased(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("NAMA MAHASISWA");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setText("TEMPAT LAHIR");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("TANGGAL LAHIR");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("TELEPHONE");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setText("ALAMAT");

        btn_simpanmahasiswa.setBackground(new java.awt.Color(153, 153, 153));
        btn_simpanmahasiswa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_simpanmahasiswa.setText("SIMPAN");
        btn_simpanmahasiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanmahasiswaActionPerformed(evt);
            }
        });

        btn_ubahmahasiswa.setBackground(new java.awt.Color(153, 153, 153));
        btn_ubahmahasiswa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_ubahmahasiswa.setText("UBAH");
        btn_ubahmahasiswa.setEnabled(false);
        btn_ubahmahasiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ubahmahasiswaActionPerformed(evt);
            }
        });

        btn_hapusmahasiswa.setBackground(new java.awt.Color(153, 153, 153));
        btn_hapusmahasiswa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_hapusmahasiswa.setText("HAPUS");
        btn_hapusmahasiswa.setEnabled(false);
        btn_hapusmahasiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusmahasiswaActionPerformed(evt);
            }
        });

        btn_clearmahasiswa.setBackground(new java.awt.Color(153, 153, 153));
        btn_clearmahasiswa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_clearmahasiswa.setText("CLEAR");
        btn_clearmahasiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearmahasiswaActionPerformed(evt);
            }
        });

        tbl_mahasiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbl_mahasiswa.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tbl_mahasiswa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_mahasiswaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_mahasiswa);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setText("JUMLAH DATA");

        lbl_mahasiswa.setBackground(new java.awt.Color(255, 255, 0));
        lbl_mahasiswa.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_mahasiswa.setForeground(new java.awt.Color(204, 204, 0));
        lbl_mahasiswa.setText("0");

        tanggallahirmahasiswa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tanggallahirmahasiswaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout TAB_MAHASISWALayout = new javax.swing.GroupLayout(TAB_MAHASISWA);
        TAB_MAHASISWA.setLayout(TAB_MAHASISWALayout);
        TAB_MAHASISWALayout.setHorizontalGroup(
            TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_MAHASISWALayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, TAB_MAHASISWALayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_mahasiswa))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 557, Short.MAX_VALUE)
                    .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(TAB_MAHASISWALayout.createSequentialGroup()
                            .addComponent(btn_simpanmahasiswa)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_ubahmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_hapusmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btn_clearmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(TAB_MAHASISWALayout.createSequentialGroup()
                            .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel11)
                                .addComponent(jLabel10)
                                .addComponent(jLabel9)
                                .addComponent(jLabel12)
                                .addComponent(jLabel13)
                                .addComponent(jLabel14))
                            .addGap(47, 47, 47)
                            .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(alamatmahasiswa)
                                .addComponent(telephonemahasiswa)
                                .addComponent(tanggallahirmahasiswa, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                                .addComponent(namamahasiswa)
                                .addComponent(tempatlahirmahasiswa)
                                .addComponent(npmmahasiswa)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TAB_MAHASISWALayout.setVerticalGroup(
            TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_MAHASISWALayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TAB_MAHASISWALayout.createSequentialGroup()
                        .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(npmmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(namamahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(tempatlahirmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel12))
                    .addComponent(tanggallahirmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(telephonemahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(alamatmahasiswa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_simpanmahasiswa)
                    .addComponent(btn_ubahmahasiswa)
                    .addComponent(btn_hapusmahasiswa)
                    .addComponent(btn_clearmahasiswa))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(TAB_MAHASISWALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_mahasiswa)
                    .addComponent(jLabel15))
                .addGap(8, 8, 8))
        );

        jTabbedPane1.addTab("MAHASISWA", TAB_MAHASISWA);

        TAB_MATAKULIAH.setBackground(new java.awt.Color(0, 153, 153));
        TAB_MATAKULIAH.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setText("KODE");

        kodematakuliah.setText("KODE-000");
        kodematakuliah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                kodematakuliahKeyReleased(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setText("MATA KULIAH");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("NAMA DOSEN");

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setText("SKS");

        btn_simpanmatakuliah.setBackground(new java.awt.Color(153, 153, 153));
        btn_simpanmatakuliah.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_simpanmatakuliah.setText("SIMPAN");
        btn_simpanmatakuliah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanmatakuliahActionPerformed(evt);
            }
        });

        btn_ubahmatakuliah.setBackground(new java.awt.Color(153, 153, 153));
        btn_ubahmatakuliah.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_ubahmatakuliah.setText("UBAH");
        btn_ubahmatakuliah.setEnabled(false);
        btn_ubahmatakuliah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ubahmatakuliahActionPerformed(evt);
            }
        });

        btn_hapusmatakuliah.setBackground(new java.awt.Color(153, 153, 153));
        btn_hapusmatakuliah.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_hapusmatakuliah.setText("HAPUS");
        btn_hapusmatakuliah.setEnabled(false);
        btn_hapusmatakuliah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusmatakuliahActionPerformed(evt);
            }
        });

        btn_clearmatakuliah.setBackground(new java.awt.Color(153, 153, 153));
        btn_clearmatakuliah.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_clearmatakuliah.setText("CLEAR");
        btn_clearmatakuliah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_clearmatakuliahActionPerformed(evt);
            }
        });

        tbl_matakuliah.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        tbl_matakuliah.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tbl_matakuliah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_matakuliahMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_matakuliah);

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setText("JUMLAH DATA");

        lbl_matakuliah.setBackground(new java.awt.Color(255, 255, 0));
        lbl_matakuliah.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lbl_matakuliah.setForeground(new java.awt.Color(204, 204, 0));
        lbl_matakuliah.setText("0");

        sksmatakuliah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sksmatakuliahActionPerformed(evt);
            }
        });

        namadosenmatakuliah.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Dosen" }));
        namadosenmatakuliah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                namadosenmatakuliahMousePressed(evt);
            }
        });

        javax.swing.GroupLayout TAB_MATAKULIAHLayout = new javax.swing.GroupLayout(TAB_MATAKULIAH);
        TAB_MATAKULIAH.setLayout(TAB_MATAKULIAHLayout);
        TAB_MATAKULIAHLayout.setHorizontalGroup(
            TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, TAB_MATAKULIAHLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbl_matakuliah))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 532, Short.MAX_VALUE)
                    .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                        .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                                .addComponent(btn_simpanmatakuliah)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_ubahmatakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_hapusmatakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btn_clearmatakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                                .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel22))
                                .addGap(47, 47, 47)
                                .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(sksmatakuliah, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
                                    .addComponent(namamatakuliah)
                                    .addComponent(kodematakuliah)
                                    .addComponent(namadosenmatakuliah, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(15, 15, 15)))
                .addGap(22, 47, Short.MAX_VALUE))
        );
        TAB_MATAKULIAHLayout.setVerticalGroup(
            TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                        .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(kodematakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 16, 16)
                        .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(namamatakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel21)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel22))
                    .addGroup(TAB_MATAKULIAHLayout.createSequentialGroup()
                        .addComponent(namadosenmatakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(sksmatakuliah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(98, 98, 98)
                .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_simpanmatakuliah)
                    .addComponent(btn_ubahmatakuliah)
                    .addComponent(btn_hapusmatakuliah)
                    .addComponent(btn_clearmatakuliah))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(TAB_MATAKULIAHLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_matakuliah)
                    .addComponent(jLabel25))
                .addGap(8, 8, 8))
        );

        jTabbedPane1.addTab("MATA KULIAH", TAB_MATAKULIAH);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 636, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jTabbedPane1)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 628, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jTabbedPane1)
                    .addContainerGap()))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_simpandosenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpandosenActionPerformed
        // TODO add your handling code here:
        if(getValidateDataDosen()){
            try {
                String sql = "INSERT INTO `tb_dosen` VALUES (?, ?, ?, ?, ?, ?)";
                java.sql.Connection conn = config.configDB();
                java.sql.PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, nidndosen.getText());
                ps.setString(2, namadosen.getText());
                ps.setString(3, tempatlahirdosen.getText());
                ps.setString(4, tanggallahirdosen.getText());
                ps.setString(5, telephonedosen.getText());
                ps.setString(6, alamatdosen.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "TAMBAH DATA BERHASIL");
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(rootPane, "TAMBAH DATA GAGAL : " + e);
            }
        }
        getTableDosen();
    }//GEN-LAST:event_btn_simpandosenActionPerformed

    private void tanggallahirdosenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tanggallahirdosenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tanggallahirdosenActionPerformed

    private void btn_simpanmahasiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanmahasiswaActionPerformed
        // TODO add your handling code here:
        if(getValidateDataMahasiswa()){
            try {
                String sql = "INSERT INTO `tb_mahasiswa` VALUES (?, ?, ?, ?, ?, ?)";
                java.sql.Connection conn = config.configDB();
                java.sql.PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, npmmahasiswa.getText());
                ps.setString(2, namamahasiswa.getText());
                ps.setString(3, tempatlahirmahasiswa.getText());
                ps.setString(4, tanggallahirmahasiswa.getText());
                ps.setString(5, telephonemahasiswa.getText());
                ps.setString(6, alamatmahasiswa.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "TAMBAH DATA BERHASIL");
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(rootPane, "TAMBAH DATA GAGAL : " + e);
            }
        }
        getTableMahasiswa();
    }//GEN-LAST:event_btn_simpanmahasiswaActionPerformed

    private void btn_simpanmatakuliahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanmatakuliahActionPerformed
        // TODO add your handling code here:
        if(getValidateDataMataKuliah()){
            try {
                String sql = "INSERT INTO `tb_matakuliah` VALUES (?, ?, ?, ?)";
                java.sql.Connection conn = config.configDB();
                java.sql.PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, kodematakuliah.getText());
                ps.setString(2, namamatakuliah.getText());
                ps.setString(3, String.valueOf(namadosenmatakuliah.getSelectedItem()));
                ps.setString(4, sksmatakuliah.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(rootPane, "TAMBAH DATA BERHASIL");
            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(rootPane, "TAMBAH DATA GAGAL : " + e);
            }
        }
        getTableMataKuliah();
    }//GEN-LAST:event_btn_simpanmatakuliahActionPerformed

    private void sksmatakuliahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sksmatakuliahActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sksmatakuliahActionPerformed

    private void tanggallahirmahasiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tanggallahirmahasiswaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tanggallahirmahasiswaActionPerformed

    private void btn_cleardosenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cleardosenActionPerformed
        // TODO add your handling code here:
        nidndosen.setText("ID-DOSEN-000");
        namadosen.setText("");
        tempatlahirdosen.setText("");
        getTanggal();
        telephonedosen.setText("");
        alamatdosen.setText("");
    }//GEN-LAST:event_btn_cleardosenActionPerformed

    private void tbl_dosenMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_dosenMouseClicked
        // TODO add your handling code here:
        int row = tbl_dosen.getSelectedRow();
        
        nidndosen.setText(String.valueOf(tbl_dosen.getValueAt(row, 0)));
        namadosen.setText(String.valueOf(tbl_dosen.getValueAt(row, 1)));
        tempatlahirdosen.setText(String.valueOf(tbl_dosen.getValueAt(row, 2)));
        tanggallahirdosen.setText(String.valueOf(tbl_dosen.getValueAt(row, 3)));
        telephonedosen.setText(String.valueOf(tbl_dosen.getValueAt(row, 4)));
        alamatdosen.setText(String.valueOf(tbl_dosen.getValueAt(row, 5)));
                
        btn_ubahdosen.setEnabled(true);
        btn_hapusdosen.setEnabled(true);
    }//GEN-LAST:event_tbl_dosenMouseClicked

    private void btn_ubahdosenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ubahdosenActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "UPDATE `tb_dosen` SET `nidn`=?,`nama_dosen`=?,`tempat_lahir`=?,`tanggal_lahir`=?,`no_telepon`=?,`alamat`=? WHERE `nidn`=?";
            java.sql.Connection conn = config.configDB();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nidndosen.getText());
            ps.setString(2, namadosen.getText());
            ps.setString(3, tempatlahirdosen.getText());
            ps.setString(4, tanggallahirdosen.getText());
            ps.setString(5, telephonedosen.getText());
            ps.setString(6, alamatdosen.getText());
            ps.setString(7, nidndosen.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "UPDATE DATA BERHASIL");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "UPDATE DATA GAGAL : " + e);
        }
        getTableDosen();
        btn_ubahdosen.setEnabled(false);
        btn_hapusdosen.setEnabled(false);
    }//GEN-LAST:event_btn_ubahdosenActionPerformed

    private void btn_hapusdosenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusdosenActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "DELETE FROM `tb_dosen` WHERE nidn=?";
            java.sql.Connection conn = config.configDB();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nidndosen.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "HAPUS DATA BERHASIL");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "HAPUS DATA GAGAL : " + e);
        }
        getTableDosen();
        btn_ubahdosen.setEnabled(false);
        btn_hapusdosen.setEnabled(false);
    }//GEN-LAST:event_btn_hapusdosenActionPerformed

    private void nidndosenKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nidndosenKeyReleased
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        model.addColumn("NIDN");
        model.addColumn("NAMA DOSEN");
        model.addColumn("TEMPAT LAHIR");
        model.addColumn("TANGGAL LAHIR");
        model.addColumn("NO TELEPON");
        model.addColumn("ALAMAT");
        
        try {
            
            String sql = "SELECT * FROM tb_dosen WHERE nidn LIKE '%"+nidndosen.getText()+"%'";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {                
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, "GAGAL MEMUAT DATA TABEL DOSEN" + e);
        }
        tbl_dosen.setModel(model);
        setLayoutTable();
    }//GEN-LAST:event_nidndosenKeyReleased

    private void btn_ubahmahasiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ubahmahasiswaActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "UPDATE `tb_mahasiswa` SET `npm`=?,`nama_mahasiswa`=?,`tempat_lahir`=?,`tanggal_lahir`=?,`no_telepon`=?,`alamat`=? WHERE `npm`=?";
            java.sql.Connection conn = config.configDB();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, npmmahasiswa.getText());
            ps.setString(2, namamahasiswa.getText());
            ps.setString(3, tempatlahirmahasiswa.getText());
            ps.setString(4, tanggallahirmahasiswa.getText());
            ps.setString(5, telephonemahasiswa.getText());
            ps.setString(6, alamatmahasiswa.getText());
            ps.setString(7, npmmahasiswa.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "UPDATE DATA BERHASIL");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "UPDATE DATA GAGAL : " + e);
        }
        getTableMahasiswa();
        btn_ubahmahasiswa.setEnabled(false);
        btn_hapusmahasiswa.setEnabled(false);
    }//GEN-LAST:event_btn_ubahmahasiswaActionPerformed

    private void btn_hapusmahasiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusmahasiswaActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "DELETE FROM `tb_mahasiswa` WHERE npm=?";
            java.sql.Connection conn = config.configDB();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, npmmahasiswa.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "HAPUS DATA BERHASIL");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "HAPUS DATA GAGAL : " + e);
        }
        getTableMahasiswa();
        btn_ubahmahasiswa.setEnabled(false);
        btn_hapusmahasiswa.setEnabled(false);
    }//GEN-LAST:event_btn_hapusmahasiswaActionPerformed

    private void npmmahasiswaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_npmmahasiswaKeyReleased
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        model.addColumn("NPM");
        model.addColumn("NAMA MAHASISWA");
        model.addColumn("TEMPAT LAHIR");
        model.addColumn("TANGGAL LAHIR");
        model.addColumn("NO TELEPON");
        model.addColumn("ALAMAT");
        
        try {
            
            String sql = "SELECT * FROM tb_mahasiswa WHERE npm LIKE '%"+npmmahasiswa.getText()+"%'";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {                
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6)});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, "GAGAL MEMUAT DATA TABEL DOSEN" + e);
        }
        tbl_mahasiswa.setModel(model);
        setLayoutTable();
    }//GEN-LAST:event_npmmahasiswaKeyReleased

    private void btn_clearmahasiswaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearmahasiswaActionPerformed
        // TODO add your handling code here:
        kodematakuliah.setText("ID-MHS-000");
        namamahasiswa.setText("");
        tempatlahirmahasiswa.setText("");
        getTanggal();
        telephonemahasiswa.setText("");
        alamatmahasiswa.setText("");
    }//GEN-LAST:event_btn_clearmahasiswaActionPerformed

    private void tbl_mahasiswaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_mahasiswaMouseClicked
        // TODO add your handling code here:
        int row = tbl_mahasiswa.getSelectedRow();
        
        npmmahasiswa.setText(String.valueOf(tbl_mahasiswa.getValueAt(row, 0)));
        namamahasiswa.setText(String.valueOf(tbl_mahasiswa.getValueAt(row, 1)));
        tempatlahirmahasiswa.setText(String.valueOf(tbl_mahasiswa.getValueAt(row, 2)));
        tanggallahirmahasiswa.setText(String.valueOf(tbl_mahasiswa.getValueAt(row, 3)));
        telephonemahasiswa.setText(String.valueOf(tbl_mahasiswa.getValueAt(row, 4)));
        alamatmahasiswa.setText(String.valueOf(tbl_mahasiswa.getValueAt(row, 5)));
                
        btn_ubahmahasiswa.setEnabled(true);
        btn_hapusmahasiswa.setEnabled(true);
    }//GEN-LAST:event_tbl_mahasiswaMouseClicked

    private void btn_clearmatakuliahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_clearmatakuliahActionPerformed
        // TODO add your handling code here:
        kodematakuliah.setText("KODE-000");
        namamatakuliah.setText("");
        namadosenmatakuliah.removeAllItems();
        getListDosen();
        sksmatakuliah.setText("");
    }//GEN-LAST:event_btn_clearmatakuliahActionPerformed

    private void btn_hapusmatakuliahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusmatakuliahActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "DELETE FROM `tb_matakuliah` WHERE kode_matkul=?";
            java.sql.Connection conn = config.configDB();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, kodematakuliah.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "HAPUS DATA BERHASIL");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "HAPUS DATA GAGAL : " + e);
        }
        getTableMataKuliah();
        btn_ubahmatakuliah.setEnabled(false);
        btn_hapusmatakuliah.setEnabled(false);
    }//GEN-LAST:event_btn_hapusmatakuliahActionPerformed

    private void btn_ubahmatakuliahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ubahmatakuliahActionPerformed
        // TODO add your handling code here:
        try {
            String sql = "UPDATE `tb_matakuliah` SET `kode_matkul`=?,`mata_kuliah`=?,`nama_dosen`=?,`sks`=? WHERE `kode_matkul`=?";
            java.sql.Connection conn = config.configDB();
            java.sql.PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, kodematakuliah.getText());
            ps.setString(2, namamatakuliah.getText());
            ps.setString(3, String.valueOf(namadosenmatakuliah.getSelectedItem()));
            ps.setString(4, sksmatakuliah.getText());
            ps.setString(5, kodematakuliah.getText());
            ps.executeUpdate();
            JOptionPane.showMessageDialog(rootPane, "UPDATE DATA BERHASIL");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, "UPDATE DATA GAGAL : " + e);
        }
        getTableMataKuliah();
        btn_ubahmatakuliah.setEnabled(false);
        btn_hapusmatakuliah.setEnabled(false);
    }//GEN-LAST:event_btn_ubahmatakuliahActionPerformed

    private void kodematakuliahKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_kodematakuliahKeyReleased
        // TODO add your handling code here:
        DefaultTableModel model = new DefaultTableModel();
        model.getDataVector().removeAllElements();
        model.fireTableDataChanged();
        model.addColumn("KODE MATA KULIAH");
        model.addColumn("NAMA MATA KULIAH");
        model.addColumn("NAMA DOSEN");
        model.addColumn("SKS");
        
        try {
            
            String sql = "SELECT * FROM tb_matakuliah WHERE kode_matkul LIKE '%"+kodematakuliah.getText()+"%'";
            java.sql.Connection conn = config.configDB();
            java.sql.Statement st = conn.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {                
                model.addRow(new Object[]{rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)});
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(rootPane, "GAGAL MEMUAT DATA TABEL MATA KULIAH" + e);
        }
        tbl_matakuliah.setModel(model);
        setLayoutTable();
    }//GEN-LAST:event_kodematakuliahKeyReleased

    private void tbl_matakuliahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_matakuliahMouseClicked
        // TODO add your handling code here:
        int row = tbl_matakuliah.getSelectedRow();
        
        kodematakuliah.setText(String.valueOf(tbl_matakuliah.getValueAt(row, 0)));
        namamatakuliah.setText(String.valueOf(tbl_matakuliah.getValueAt(row, 1)));
        namadosenmatakuliah.setSelectedItem(String.valueOf(tbl_matakuliah.getValueAt(row, 2)));
        sksmatakuliah.setText(String.valueOf(tbl_matakuliah.getValueAt(row, 3)));
                
        btn_ubahmatakuliah.setEnabled(true);
        btn_hapusmatakuliah.setEnabled(true);
    }//GEN-LAST:event_tbl_matakuliahMouseClicked

    private void namadosenmatakuliahMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_namadosenmatakuliahMousePressed
        // TODO add your handling code here:
        getListDosen();
    }//GEN-LAST:event_namadosenmatakuliahMousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        try {
            UIManager.setLookAndFeel( new FlatDarkLaf() );
        } catch( Exception ex ) {
            System.err.println( "Failed to initialize LaF" );
        }

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel TAB_DOSEN;
    private javax.swing.JPanel TAB_MAHASISWA;
    private javax.swing.JPanel TAB_MATAKULIAH;
    private javax.swing.JTextField alamatdosen;
    private javax.swing.JTextField alamatmahasiswa;
    private javax.swing.JButton btn_cleardosen;
    private javax.swing.JButton btn_clearmahasiswa;
    private javax.swing.JButton btn_clearmatakuliah;
    private javax.swing.JButton btn_hapusdosen;
    private javax.swing.JButton btn_hapusmahasiswa;
    private javax.swing.JButton btn_hapusmatakuliah;
    private javax.swing.JButton btn_simpandosen;
    private javax.swing.JButton btn_simpanmahasiswa;
    private javax.swing.JButton btn_simpanmatakuliah;
    private javax.swing.JButton btn_ubahdosen;
    private javax.swing.JButton btn_ubahmahasiswa;
    private javax.swing.JButton btn_ubahmatakuliah;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField kodematakuliah;
    private javax.swing.JLabel lbl_dosen;
    private javax.swing.JLabel lbl_mahasiswa;
    private javax.swing.JLabel lbl_matakuliah;
    private javax.swing.JTextField namadosen;
    private javax.swing.JComboBox<String> namadosenmatakuliah;
    private javax.swing.JTextField namamahasiswa;
    private javax.swing.JTextField namamatakuliah;
    private javax.swing.JTextField nidndosen;
    private javax.swing.JTextField npmmahasiswa;
    private javax.swing.JTextField sksmatakuliah;
    private javax.swing.JTextField tanggallahirdosen;
    private javax.swing.JTextField tanggallahirmahasiswa;
    private javax.swing.JTable tbl_dosen;
    private javax.swing.JTable tbl_mahasiswa;
    private javax.swing.JTable tbl_matakuliah;
    private javax.swing.JTextField telephonedosen;
    private javax.swing.JTextField telephonemahasiswa;
    private javax.swing.JTextField tempatlahirdosen;
    private javax.swing.JTextField tempatlahirmahasiswa;
    // End of variables declaration//GEN-END:variables
}
