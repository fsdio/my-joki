# DATA MAHASISWA MELIPUTI
# 1. NAMA
# 2. NILAI [TUGAS, UTS, UAS]
# 3. NILAI AKHIR
data_mahasiswa = {}

import os
clear = lambda: os.system('cls')

# METHOD MENU
def menu():
    print("====================") 
    print("Menu Pilihan")
    print("--------------------")
    print("1. Tambah Data")
    print("2. Ubah Data")
    print("3. Hapus Data")
    print("4. Tampilkan Data")
    print("5. Cari Data")
    print("6. Hapus Semua Data")
    print("====================") 
    choice = int(input("Masukkan Pilihan : "))
    return choice
    
def tambah():
    print("\n# TAMBAH DATA MAHASISWA")
    nama  = input("nama\t\t: ")
    tugas = int(input("tugas\t\t: "))
    uts   = int(input("uts\t\t: "))
    uas   = int(input("uas\t\t: "))
    nilai_akhir = int(((tugas-((tugas/100)*30))+(uts-((uts/100)*35))+(uas-((uas/100)*35))))
    new_data = {nama :{ "tugas":tugas, "uts":uts, "uas":uas, "nilai_akhir":nilai_akhir}}
    data_mahasiswa.update(new_data)
    
def ubah(nama):
    print("\n# UBAH DATA MAHASISWA SESUAI NAMA")
    if(len(data_mahasiswa)>0):
      for i in data_mahasiswa:
        if (i == nama):
          tugas = int(input("tugas\t\t: "))
          uts   = int(input("uts\t\t: "))
          uas   = int(input("uas\t\t: "))
          nilai_akhir = int(((tugas-((tugas/100)*30))+(uts-((uts/100)*35))+(uas-((uas/100)*35))))
          new_data = {i :{ "tugas":tugas, "uts":uts, "uas":uas, "nilai_akhir":nilai_akhir}}
          data_mahasiswa.update(new_data)
          break
        else:
          print("DATA TIDAK ADA")
    else:
      print("data kosong")
    
def tampil():
    print("\n# TAMPIL SEMUA DATA MAHASISWA")
    if(len(data_mahasiswa)>0):
      for i in data_mahasiswa:
        print(i, "\t\t: ", data_mahasiswa.get(i))
    else:
      print("data kosong")
      
def hapus(nama):
    print("\n# HAPUS DATA MAHASISWA SESUAI NAMA")
    if(len(data_mahasiswa)>0):
      for i in data_mahasiswa.keys():
        if (i == nama):
          data_mahasiswa.pop(i)
          print("data ", i, " Terhapus.")
          getRun()
    else:
      print("data kosong")
    
def cari(nama):
    print("\n# CARI DATA MAHASISWA SESUAI NAMA")
    if(len(data_mahasiswa)>0):
      for i in data_mahasiswa:
        if (i == nama):
          print(i, "\t\t: ", data_mahasiswa.get(i))
    else:
      print("data kosong")

def getRun():      
  while True:
    choice = menu()
    if choice == 1:
      clear()
      tambah()
    elif choice == 2:
      clear()
      nama = input("masukan nama : ")
      ubah(nama)
    elif choice == 3:
      clear()
      nama = input("masukan nama : ")
      hapus(nama)
    elif choice == 4:
      clear()
      tampil()
    elif choice == 5:
      clear()
      nama = input("masukan nama : ")
      cari(nama)
    elif choice == 6:
      clear()
      data_mahasiswa.clear()
    else:
      break
    
getRun()