# **PRAKTIKUM-1**
> ## **FLOWCHART**
>
> ![](/PRAKTIKUM-1/praktikum_1.png "praktikum_1.png ")

> ## **VARIABEL DATA AWAL**
>
> variabel `data = []` untuk menampung data mahasiswa.

> ## **FUNGSI TAMBAH DATA**
>
> 1. nama fungsinya `tambah` tanpa parameter.
> 1. mempunyai 2 variabel untuk menerima data `nama` dan `nilai` mahasiswa.
> 1. selanjutnya dari kedua data tersebut akan dimasukan ke variabel `data`.

> ## **FUNGSI TAMPILKAN**
>
> 1. nama fungsinya `tambah` tanpa parameter.
> 1. mempunyai 1 statement menggunakan perulangan `for` sebanyak variabel `data`.
> 1. sehingga data `nama` dan `nilai` akan muncul.

> ## **FUNGSI HAPUS**
>
> 1. nama fungsinya `hapus` dengan parameter `nama` karena akan digunakan untuk menghapus data berdasarkan nama.
> 1. mempunyai 2 statement : 
>      + perulangan `for` sebanyak variabel `data` digunakan untuk validasi data pada variabel `data`.
>      + pengkodisian `if:else` untuk melakukan penghapusan sesuai data `nama`.
> 1. sehingga data dengan `nama` akan terhapus.

> ## **FUNGSI UBAH**
>
> 1. nama fungsinya `ubah` dengan parameter `nama` karena akan digunakan untuk mengubah data berdasarkan nama.
> 1. mempunyai 2 statement : 
>      + perulangan `for` sebanyak variabel `data` digunakan untuk validasi data pada variabel `data`.
>      + pengkodisian `if:else` untuk melakukan penghapusan sesuai data `nama`.
>      + jika data `nama` sesuai ada maka nilai dapat diubah.
> 1. sehingga data dengan `nama` akan berubah.