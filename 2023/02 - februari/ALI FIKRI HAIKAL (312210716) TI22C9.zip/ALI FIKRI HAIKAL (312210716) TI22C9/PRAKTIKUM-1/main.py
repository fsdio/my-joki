data = []

def tambah():
    nama  = input("nama  : ")
    nilai = input("nilai : ")
    data.append({"nama": nama, "nilai": nilai})

def tampilkan():
    for i in data:
        print("Nama: ", i["nama"], " | Nilai: ", i["nilai"])

def hapus(nama):
    for i in data:
        if i["nama"] == nama:
            data.remove(i)
            print("Data ", nama, "berhasil dihapus")
            break
    else:
        print("Data tidak ditemukan")

def ubah(nama):
    for i in data:
        if i["nama"] == nama:
            print("Ubah Data ", nama)
            i["nilai"] = input("masukan nilai baru :")
            print("Data ", nama, "berhasil diubah")
            break
    else:
        print("Data tidak ditemukan")

# contoh pemanggilan fungsi
tambah()
tambah()
tambah()

tampilkan()
hapus("Budi")
tampilkan()
ubah("Caca")
tampilkan()
