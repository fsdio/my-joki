# **PRAKTIKUM-3**
> ## **FLOWCHART**
>
> ![](/PRAKTIKUM-3/praktikum_3.png "praktikum_3.png ")

> ## **VARIABEL DATA AWAL**
>
> variabel `data_mahasiswa = {}` dictionary untuk menampung data mahasiswa.

> ## **IMPORT LIBRARY `os`**
>
> untuk memasukan perintah `cls` pada command prompts.

> ## **FUNGSI MENU**
>
> 1. nama fungsinya `menu()` tanpa parameter namun data mengembalikan nilai `int`.
> 1. mempunyai 1 variabel untuk menerima data `choice` untuk return dari method `menu`.
> 1. dan variabel `choice` dimasukan oleh user.

> ## **FUNGSI TAMBAH DATA**
>
> 1. nama fungsinya `tambah()` tanpa parameter.
> 1. memiliki 2 statement :
>       + `while loop` yang digunakan untuk perulangan input data `data_mahasiswa` dan user bisa berhenti jika melakukan input `T/t`.
>       + `if:else` jika
>           + user input `T/t` maka akan menampilkan data `data_mahasiswa` dan lanjut ke method `getRun()`.
>           + user input `Y/y` maka akan insert data `data_mahasiswa`.
> 1. mempunyai 6 variabel :
>       + inputan : untuk validasi user akan input lagi?.
>       + nama : nama mahasiswa.
>       + tugas : tugas mahasiswa.
>       + uts : uts mahasiswa.
>       + uas : uas mahasiswa.
>       + nilai_akhir : tugas:30%, uts:35%, uas:35%.
>       + new_data : untuk menyimpan data mahasiswa baru.
> 1. selanjutnya dari `new_data` akan dimasukan ke `data_mahasiswa`.

> ## **FUNGSI UBAH DATA**
>
> 1. nama fungsinya `ubah(nama)` dengan parameter `nama` yang digunakan untuk ubah data berdasarkan nama.
> 1. memiliki 3 statement :
>       + `if:else` yang digunakan untuk validasi cek data `data_mahasiswa`.
>       + `for loop` yang digunakan untuk pencarian data sesuai data `nama`.
>       + `if:else` yang digunakan jika data `nama` sudah ditemukan dan data `data_mahahasiswa` dapat diubah.
> 1. mempunyai 5 variabel :
>       + tugas : tugas mahasiswa.
>       + uts : uts mahasiswa.
>       + uas : uas mahasiswa.
>       + nilai_akhir : tugas:30%, uts:35%, uas:35%.
>       + new_data : untuk menyimpan data mahasiswa baru.
> 1. selanjutnya dari `new_data` akan diubah ke `data_mahasiswa` sesuai data `nama` yang ada.

> ## **FUNGSI TAMPIL DATA**
>
> 1. nama fungsinya `tampil()` tanpa parameter.
> 1. memiliki 2 statement :
>       + `if:else` yang digunakan untuk validasi cek data `data_mahasiswa`.
>       + `for loop` yang digunakan untuk menampilkan semua data.

> ## **FUNGSI HAPUS DATA**
>
> 1. nama fungsinya `hapus(nama)` dengan parameter `nama` yang digunakan untuk hapus data berdasarkan nama.
> 1. memiliki 3 statement :
>       + `if:else` yang digunakan untuk validasi cek data `data_mahasiswa`.
>       + `for loop` yang digunakan untuk pencarian data sesuai data `nama`.
>       + `if:else` yang digunakan jika data `nama` sudah ditemukan dan data `data_mahahasiswa` dapat dihapus.
> 1. selanjutnya akan dihapus `data_mahasiswa` sesuai data `nama` yang ada.

> ## **FUNGSI CARI DATA**
>
> 1. nama fungsinya `cari(nama)` dengan parameter `nama` yang digunakan untuk mencari data berdasarkan nama.
> 1. memiliki 3 statement :
>       + `if:else` yang digunakan untuk validasi cek data `data_mahasiswa`.
>       + `for loop` yang digunakan untuk pencarian data sesuai data `nama` lalu ditampilkan.

> ## **FUNGSI MENU UTAMA DATA**
>
> 1. nama fungsinya `getRun()` tanpa parameter.
> 1. mempunyai 1 variabel :
>       + choice : diambil dari hasil return method `menu()`
> 1. memiliki 2 statement :
>       + `while loop` yang digunakan untuk sesuai kondisi.
>       + `if:else` jika :
>           + `choice` sama dengan `1` maka memanggil method `clear()` dan `tambah()`.
>           + `choice` sama dengan `2` maka memanggil method `clear()` dan `ubah(nama)`.
>           + `choice` sama dengan `3` maka memanggil method `clear()` dan `hapus(nama)`.
>           + `choice` sama dengan `4` maka memanggil method `clear()` dan `tampil()`.
>           + `choice` sama dengan `5` maka memanggil method `clear()` dan `cari(nama)`.
>           + semua kondisi tidak terpenuhi maka program berhenti.